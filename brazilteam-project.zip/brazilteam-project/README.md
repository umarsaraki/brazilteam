# Brazilteam — Deployment Guide

This folder is a complete, ready-to-deploy website project (not just one file).
It contains everything a hosting service needs to build your site and give you
a live link.

## Fastest path (no coding tools needed on your computer)

1. Go to https://github.com and create a free account (if you don't have one).
2. Create a **new repository** (e.g. name it `brazilteam`).
3. Upload every file/folder in this project to that repository
   (GitHub's web page has an "Add file → Upload files" button — drag this
   whole folder in).
4. Go to https://vercel.com and sign up using your GitHub account.
5. Click **New Project**, select your `brazilteam` repository, leave the
   default settings (Vercel auto-detects Vite/React), and click **Deploy**.
6. In 1–2 minutes, Vercel gives you a live link like
   `https://brazilteam.vercel.app` — that is your real website.
7. Anyone can now open that link, Register, and use the site. You can later
   attach your own domain name (e.g. brazilteam.com) from the Vercel project
   settings → Domains.

## Alternative (Netlify)

Same idea: sign up at https://netlify.com with GitHub, "Add new site →
Import an existing project", pick the repository, deploy. Netlify also
gives you a free live link.

## Important reminders

- The Supabase project (auth, database) is already connected in the code —
  you don't need to configure anything extra there for login/register to work.
- Posts, Chairman Posts, Follows, and Banners already save for real to
  Supabase. Messages, Meeting, Polls, Support, Forms, and Verification still
  need to be connected the same way — tell Claude to continue that next.
